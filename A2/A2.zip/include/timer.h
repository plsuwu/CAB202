#include "types.h"

extern volatile u16 elapsed_time;
extern u16 playback_delay;
// extern volatile u8 debounce;
