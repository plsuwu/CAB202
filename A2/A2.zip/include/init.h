void button_init(void);
void pwm_init(void);
void timer_init(void);
void spi_init(void);
void uart_init(void);
