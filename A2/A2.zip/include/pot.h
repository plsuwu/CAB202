#ifndef POT_H
#define POT_H

#include <avr/interrupt.h>
#include <avr/io.h>
#include "types.h"

#endif // POT_H
