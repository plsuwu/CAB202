#include <avr/interrupt.h>
#include <stdio.h>
#include <stdint.h>
#include <avr/io.h>

#include "spi.h"

//    1. In "spi.c", declare and implement a function spi_init() that will
//       initialise SPI0 in unbuffered mode, such that data can be written
//       to the shift register that controls the 7-segment display.
//
//       This function should also enable the SPI interrupt via the IE bit
//       in INTCTRL.
//    2. Declare and implement the function spi_write(uint8_t b) which
//       will write the byte b out via the SPI interface.
//    3. Declare and implement an ISR that handles the SPI interrupt, and
//       also creates a rising edge on the DISP LATCH net.
//
//       You will need to add some code to spi_init() to enable the
//       required pins as outputs.
//
//    Declare prototypes for these functions in "spi.h" and include
//    "spi.h" at the top of "tutorial09.c".
//
//    Once this exercise is complete, uncomment the lines below. The
//    7-segment display should be blank after this code executes.

void spi_init(void) {
    cli();
    // SPI pins => PCO..=3
    PORTMUX.SPIROUTEA = PORTMUX_SPI0_ALT1_gc;
    PORTC.DIR |= (PIN0_bm | PIN2_bm);           // SCK on PC0 and MOSI on PC2 as outputs
    PORTA.DIR |= PIN1_bm;                       // DISP LATCH as output


    SPI0.CTRLA = SPI_MASTER_bm;
    SPI0.CTRLB = SPI_SSD_bm;                    // host mode i think
    SPI0.CTRLA |= SPI_ENABLE_bm;                // enable
    SPI0.INTCTRL |= SPI_IE_bm;

    sei();
}

// in host mode, writing to DATA register starts a tx
void spi_write(uint8_t b) {
    SPI0.DATA = b;                              // write data to SPI DATA register
}

uint8_t spi_read(void) {
    return SPI0.DATA;                           // read SPI DATA register
}
// ; 5. Repeat the following for all 8 bits in the above byte, transmitting
// ;    the MSB first so that it is shifted to Q7 after 8 clocks:
// ;    a. If the bit is a 1:
// ;         Drive the SPI MOSI net HIGH
// ;       If the bit is a 0:
// ;         Drive the SPI MOSI net LOW
// ;    b. Drive the SPI CLK net HIGH (to create a rising edge)
// ;    c. Drive the SPI CLK net LOW (to prepare for the next rising edge)
// ; 6. a. Drive the DISP LATCH net HIGH (to create a rising edge)

ISR(SPI0_INT_vect) {
    printf("INTERRUPT GENERATED, ISR HANDLED HERE");
    PORTA.OUT = PIN1_bm;
    SPI0.INTFLAGS = SPI_IF_bm;
}


