void clock_init(void);
void buttons_init(void);
