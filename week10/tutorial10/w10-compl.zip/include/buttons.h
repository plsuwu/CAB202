#include <stdint.h>

extern volatile uint8_t pb_debounced_state;

void buttons_init(void);
// void dp_init(void);
